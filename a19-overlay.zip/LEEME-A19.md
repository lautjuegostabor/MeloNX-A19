# MeloNX A19 — prototipo de integración 0.1

**Código fuente experimental. No es un IPA y no está compilado ni probado en iOS.**
Base: MeloNX 2.5 (ZIP MeloNX-master suministrado). StikJIT: 2.0.1 (ZIP StikJIT-main suministrado). Pairing e IPC: adaptados de Husk-main. No se incluyen juegos, firmware, claves, pairing files ni credenciales del usuario.

## Qué se cambió

- `src/MeloNX/MeloNX/Common/JIT`: proveedor Built-in StikJIT, coordinador, pantalla de configuración y diagnóstico, importación segura de pairing, pairing inalámbrico mediante el código Swift/Rust de Husk, IPC a extensión auxiliar por identificador real de instalación.
- `distribution/ios/a19`: fuentes de extensión, StikJIT y biblioteca Rust con Cargo.lock; scripts de compilación y empaquetado unsigned, comprobador de estructura IPA, licencias de componentes adaptados.
- `Info.plist` y bridging header: anuncio Bonjour, permiso de red local, identificador de tarea de pairing y declaraciones C para el pairing.
- `RyujinxController`: evitar intento prematuro de asignación ejecutable TXM sin CS_DEBUGGED. `NoJITView`: espera cancelable, diagnóstico y reintento explícito. No se modifica el motor C#.
- `PerformanceOverlay`: estado térmico de iOS y reemplazo del observador de batería acumulativo por suscripción ligada al ciclo de vida de SwiftUI.
- Workflow manual: variante de referencia `-Onone` y variante experimental `-O`. No publica automáticamente releases.

## Hallazgos de auditoría

1. `BreakpointJIT.framework` desensamblado con llvm-objdump: BreakGetJITMapping usa x16=1, brk 0xf00d; BreakJITDetach usa x16=0, brk 0xf00d; BreakMarkJITMapping usa brk 0x69. El universal.js de StikJIT reconoce los tres. El allocator C# prueba primero la llamada antigua y después la universal. El nuevo helper usa el script universal del framework, no el script de Husk.
2. `Ryujinx.Cpu/LightningJit/Translator.cs` y `Cache/DualMappedNoWxCache.cs`: el núcleo utiliza LightningJit, y prepara 512 MiB de espacio JIT compartido TXM más 256 MiB local. El manejador de señales solicita su propia región antes del detach. Son tamaños de regiones, no consumo real de RAM; no reducirlos a ciegas.
3. `RyujinxController.startGame` exige Increased Memory Limit y verifica si el dispositivo necesita Extended Virtual Addressing. No se desactivaron estas comprobaciones. En firma gratuita hay que comprobar también get-task-allow y la conservación del appex. El registro del helper puede consumir un identificador de App ID aunque no sea otra app visible.
4. `Options.swift` y `Options+Codable.swift`: caché de shaders deshabilitada por defecto, PTC habilitado por defecto, docked mode deshabilitado, escala 1x, recompresión de texturas deshabilitada y compilación asíncrona deshabilitada. Son funciones existentes, no nuevas optimizaciones. El motor fuerza backendThreading=on al arrancar. Evitar alterar todas juntas.
5. `MeloNXApp.swift`: MoltenVK fija máximo 128 command buffers activos y desactiva argument buffers para tier 2. Son candidatos a experimentos, no mejoras demostradas. No se cambiaron.
6. Pairing inalámbrico: la fuente de Husk advierte que el ID de bundle modificado por sideloading puede impedir la tarea de procesamiento continuo en background. En ese caso hay tiempo limitado para cambiar a Ajustes y completar el PIN. No se garantiza que la firma gratuita de SideInstaller soporte el helper ni el registro.

## Compilación (requiere Mac remoto o local)

Usar Xcode 27.1+ recomendado por el README de StikJIT, .NET 10 (global.json), XcodeGen, Rust estable con target aarch64-apple-ios y acceso a NuGet/SwiftPM/crates.io. El workflow `.github/workflows/build-ipa.yml` se lanza manualmente en un runner macOS; comprobar disponibilidad real del Xcode seleccionado. No se ha ejecutado. Alternativa local, desde la raíz del proyecto:

```bash
brew install xcodegen
distribution/ios/a19/build-dependencies.sh
xcodebuild archive -project src/MeloNX/MeloNX.xcodeproj -scheme MeloNX -configuration Release -destination 'generic/platform=iOS' -archivePath build/MeloNX.xcarchive CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' DEVELOPMENT_TEAM='' SWIFT_OPTIMIZATION_LEVEL=-Onone
distribution/ios/a19/package.sh
```

Resultado esperado de compilación exitosa: `build/MeloNX-A19-unsigned.ipa`. Requiere firma posterior. El empaquetador comprueba versiones e identificadores, existencia de binarios y script universal, no firma ni ejecución real.

## Primer test en el iPhone

1. Instalar conservando el helper y framework. No borrar ninguna app existente para una prueba no validada. Comprobar que SideInstaller conserve los permisos `get-task-allow` e `increased-memory-limit` y que la extensión sea visible en la pantalla de diagnóstico.
2. Ajustes del emulador → JIT integrado → Emparejar desde este iPhone. Seguir el flujo de modo desarrollador y PIN. Alternativa: importar un archivo válido. El registro contiene claves privadas, no compartirlo.
3. Conectar LocalDevVPN, comprobar DDI y activar JIT. Confirmar preparación real de regiones y detach exitoso. Si falla, conservar el error y no insistir con un proceso parcialmente inicializado: cerrar y volver a abrir la app.
4. Abrir un juego propio ya configurado y confirmar que funciona durante 10–20 min. Si falla por firma o RAM, resolverlo antes de optimizar.

## Prueba A/B de rendimiento (pendiente)

Comparar misma versión del juego, misma escena, batería/temperatura inicial comparable, misma resolución, sin grabación de pantalla. Registrar FPS, tiempo de frame, RAM, FIFO y nivel térmico en frío y tras 15 minutos. Primero comparar -Onone vs -O. Luego probar caché de shaders en una segunda ejecución, y un cambio por vez (texturas, resolución, comandos gráficos). La compilación asíncrona puede alterar fidelidad visual; no activarla globalmente sin probar. No prometemos aumentos de FPS sin mediciones. La activación integrada evita la app auxiliar visible, pero no acelera el juego por sí sola.

## Validación realizada en Linux

Parseo sintáctico de Swift de los archivos nuevos y principales modificados (sin SDK iOS, no typecheck ni link); sintaxis bash, parsing de YAML y plist, compilación del validador Python. Desensamblado estático del framework original. No se ejecutó Xcode, no se compiló el código Rust ni el motor .NET para iOS, no se firmó, no se instaló y no se midió rendimiento. La base tiene dependencias remotas y posibles incompatibilidades de Xcode que sólo una compilación real revelará.

Licencias: se conservan MIT de MeloNX, MPL-2.0 y licencias de StikJIT, GPL-2.0-or-later de los archivos adaptados de Husk y crate Rust. Ver `distribution/ios/a19/vendor`. Si se distribuye un binario, acompañar las fuentes correspondientes y cumplir los requisitos de licencias de todos los componentes.
