#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
mkdir -p build
command -v xcodegen >/dev/null
command -v cargo >/dev/null
xcodebuild -version
# Compile the pairing library from its pinned Cargo.lock, targeting the host's minimum OS.
rustup target add aarch64-apple-ios
(
  cd vendor/rppairing-ios
  IPHONEOS_DEPLOYMENT_TARGET=15.0 cargo build --locked --release --target aarch64-apple-ios
)
cp vendor/rppairing-ios/target/aarch64-apple-ios/release/libhusk_rppairing.a build/
python3 vendor/rppairing-ios/notices.py build/LICENSES-rppairing-crates.txt
# Compile StikJIT 2.0.1 from the user's source archive, not an unknown binary.
(
  cd vendor/StikJIT
  xcodegen generate
  xcodebuild archive -project StikJIT.xcodeproj -scheme StikJIT \
    -destination 'generic/platform=iOS' -archivePath "$HERE/build/StikJIT-iOS" \
    SKIP_INSTALL=NO BUILD_LIBRARY_FOR_DISTRIBUTION=YES CODE_SIGNING_ALLOWED=NO
)
rm -rf build/StikJIT.framework
cp -R build/StikJIT-iOS.xcarchive/Products/Library/Frameworks/StikJIT.framework build/
xcodegen generate
xcodebuild build -project MeloNXJITHelper.xcodeproj -scheme MeloNXJITHelper \
  -configuration Release -destination 'generic/platform=iOS' -derivedDataPath "$HERE/build/helper" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO DEVELOPMENT_TEAM=''
test -s build/helper/Build/Products/Release-iphoneos/MeloNXJITHelper.appex/MeloNXJITHelper
