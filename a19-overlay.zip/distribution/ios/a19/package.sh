#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
cd "$ROOT"
APP=build/Payload/MeloNX.app
mkdir -p build/Payload
rm -rf "$APP"
cp -R build/MeloNX.xcarchive/Products/Applications/MeloNX.app "$APP"
mkdir -p "$APP/PlugIns" "$APP/Frameworks" "$APP/Legal-A19"
cp -R "$HERE/build/helper/Build/Products/Release-iphoneos/MeloNXJITHelper.appex" "$APP/PlugIns/"
cp -R "$HERE/build/StikJIT.framework" "$APP/Frameworks/"
rm -rf "$APP/Frameworks/StikJIT.framework/Headers" "$APP/Frameworks/StikJIT.framework/Modules"
cp LICENSE.txt "$HERE/vendor/LICENSE-Husk-GPL-2.0.txt" "$HERE/vendor/StikJIT/LICENSE" "$HERE/build/LICENSES-rppairing-crates.txt" "$APP/Legal-A19/"
cp "$HERE/vendor/Husk-licensing.md" "$APP/Legal-A19/"
python3 "$HERE/validate-bundle.py" "$APP"
(cd build; rm -f MeloNX-A19-unsigned.ipa; zip -qry MeloNX-A19-unsigned.ipa Payload)
