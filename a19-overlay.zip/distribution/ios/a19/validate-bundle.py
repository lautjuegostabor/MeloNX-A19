"""Static packaging checks; does not prove iOS launch or JIT success."""
import sys, plistlib
from pathlib import Path
app=Path(sys.argv[1]); ext=app/'PlugIns/MeloNXJITHelper.appex'; fw=app/'Frameworks/StikJIT.framework'
read=lambda p: plistlib.loads(p.read_bytes())
a,e,f=map(read,[app/'Info.plist',ext/'Info.plist',fw/'Info.plist'])
assert e['CFBundleIdentifier'].startswith(a['CFBundleIdentifier']+'.'), 'extension ID mismatch'
assert e['CFBundleVersion']==a['CFBundleVersion'], 'build version mismatch'
assert e['CFBundleShortVersionString']==a['CFBundleShortVersionString'], 'short version mismatch'
assert e['NSExtension']['NSExtensionPrincipalClass']=='MeloNXJITHelperHandler'
assert a.get('NSBonjourServices') and a.get('BGTaskSchedulerPermittedIdentifiers')
for directory, info in [(app,a),(ext,e),(fw,f)]:
    assert (directory/info['CFBundleExecutable']).stat().st_size>0
assert (fw/'universal.js').stat().st_size>0
print('Static bundle checks passed; signing and device tests still required.')
