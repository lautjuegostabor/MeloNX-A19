import Foundation
import SwiftUI
import UniformTypeIdentifiers
import UIKit

/// Store locally; never upload, log or put pairing records in the build archive.
@MainActor enum MeloNXPairingStore {
    static var directory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("StikJIT", isDirectory: true)
    }
    static var url: URL { directory.appendingPathComponent("pairingFile.plist") }
    static var exists: Bool { FileManager.default.fileExists(atPath: url.path) }
    static func data() throws -> Data { try Data(contentsOf: url) }
    static func store(_ data: Data) throws {
        guard let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let dict = plist as? [String: Any],
              let pub = dict["public_key"] as? Data, pub.count == 32,
              let priv = dict["private_key"] as? Data, priv.count == 32,
              let id = dict["identifier"] as? String, !id.isEmpty else {
            throw NSError(domain: "MeloNXJIT", code: 10, userInfo: [NSLocalizedDescriptionKey: "El archivo no es un registro de emparejamiento remoto válido."])
        }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    static func importFile(_ source: URL) throws {
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        try store(Data(contentsOf: source))
    }
}

@MainActor final class MeloNXJITCoordinator: ObservableObject {
    static let shared = MeloNXJITCoordinator()
    @Published private(set) var status = "Configurá el emparejamiento y conectá LocalDevVPN."
    @Published private(set) var busy = false
    @Published private(set) var ready = false
    private var monitor: Task<Void, Never>?
    private var attemptedMapping = false
    private init() {}

    var signingStatus: String {
        checkAppEntitlement("get-task-allow") ? "Permiso de depuración presente" : "Falta get-task-allow"
    }
    func report(_ message: String) { status = message }
    private func gate() -> Data? {
        guard #available(iOS 26.0, *) else { status = "Requiere iOS 26 o posterior."; return nil }
        if let reason = MeloNXBuiltInJIT.unavailableReason { status = reason; return nil }
        guard !AppEnvironment.shared.isInLiveContainer else { status = "JIT integrado no disponible dentro de LiveContainer."; return nil }
        guard MeloNXBuiltInJIT.helperIdentifier != nil else { status = "Falta la extensión JIT en la instalación. Conservá las extensiones al firmar."; return nil }
        guard checkAppEntitlement("get-task-allow") else { status = "La firma no habilitó get-task-allow."; return nil }
        guard let data = try? MeloNXPairingStore.data(), !data.isEmpty else { status = "Primero emparejá el iPhone o importá un archivo válido."; return nil }
        return data
    }
    func prepare() {
        guard !busy, let data = gate() else { return }
        busy = true; status = "Comprobando LocalDevVPN y Developer Disk Image…"
        MeloNXBuiltInJIT.send(.prepare(pairingData: data)) { result in
            self.busy = false
            switch result {
            case .success(let response): self.status = response.message
            case .failure(let error): self.status = error.localizedDescription
            }
        }
    }
    func resetDDI() {
        guard !busy, gate() != nil else { return }
        busy = true; status = "Eliminando caché DDI…"
        MeloNXBuiltInJIT.send(.resetDDI) { result in
            self.busy = false
            switch result {
            case .success(let response): self.status = response.message
            case .failure(let error): self.status = error.localizedDescription
            }
        }
    }
    func enable() {
        guard !busy else { return }
        if RyujinxController.hasPreparedJITMemory && jitEnabled() {
            ready = true; status = "JIT listo."; return
        }
        ready = false
        guard let data = gate() else { return }
        // This first candidate targets the TXM path used by A19 / iOS 27.
        guard ProcessInfo.processInfo.hasTXM else { status = "Usá el método externo en dispositivos sin TXM."; return }
        busy = true; attemptedMapping = false; status = "Activando JIT (LocalDevVPN debe estar conectado)…"
        MeloNXBuiltInJIT.send(.enable(targetPID: getpid(), pairingData: data), started: {
            // The extension starts before debugserver attaches. Wait for the actual flag.
            self.monitor?.cancel()
            self.monitor = Task { @MainActor in
                while !Task.isCancelled && self.busy && !self.attemptedMapping {
                    if checkDebugged() {
                        self.attemptedMapping = true
                        self.status = "Preparando memoria ejecutable…"
                        if !RyujinxController.attemptToMapDualMapping() {
                            self.status = "No se pudo preparar la memoria JIT. Cerrá y reabrí la app antes de reintentar."
                        }
                        return
                    }
                    do { try await Task.sleep(nanoseconds: 200_000_000) } catch { return }
                }
            }
        }, completion: { result in
            self.monitor?.cancel(); self.monitor = nil; self.busy = false
            switch result {
            case .success(let response):
                self.ready = response.success && RyujinxController.hasPreparedJITMemory
                self.status = self.ready ? "JIT listo." : (response.success ? "El helper terminó, pero no se validó la memoria JIT. Reiniciá la app." : response.message)
            case .failure(let error): self.ready = false; self.status = error.localizedDescription
            }
        })
    }
}

struct MeloNXJITSetupView: View {
    @ObservedObject private var coordinator = MeloNXJITCoordinator.shared
    @ObservedObject private var pairing = OnDevicePairing.shared
    @State private var showImporter = false
    @State private var imported = false
    @Environment(\.dismiss) private var dismiss

    private var paired: Bool { imported || MeloNXPairingStore.exists }
    var body: some View {
        Form {
            Section("Diagnóstico de instalación") {
                Text(coordinator.signingStatus)
                Text(checkAppEntitlement("com.apple.developer.kernel.increased-memory-limit") ? "Memoria ampliada: presente" : "Memoria ampliada: ausente")
                Text(MeloNXBuiltInJIT.helperIdentifier == nil ? "Extensión JIT: ausente" : "Extensión JIT: presente")
            }
            Section("1. Emparejamiento") {
                Text(paired ? "Archivo de emparejamiento guardado" : "Sin emparejamiento")
                if OnDevicePairing.isSupported {
                    Button("Emparejar desde este iPhone") { pairing.start() }.disabled(pairing.active || coordinator.busy)
                    if pairing.active {
                        Text("Abrí Ajustes → Privacidad y seguridad → Modo desarrollador → Pair with MeloNX.")
                        if pairing.backgroundLimited { Text("iOS limitó el tiempo en segundo plano. Completá el emparejamiento inmediatamente.") }
                        Button("Cancelar emparejamiento", role: .cancel) { pairing.cancel() }
                    }
                    switch pairing.phase {
                    case .pin(let pin): Text("Código: \(pin)").font(.title2.monospacedDigit())
                    case .paired: Text("Emparejamiento completado")
                    case .failed(let message): Text(message).foregroundStyle(.red)
                    default: EmptyView()
                    }
                }
                Button("Importar pairing file") { showImporter = true }.disabled(pairing.active || coordinator.busy)
            }
            Section("2. LocalDevVPN y JIT") {
                Text("Conectá LocalDevVPN y regresá a MeloNX.")
                Button("Comprobar conexión y DDI") { coordinator.prepare() }.disabled(coordinator.busy || pairing.active)
                Button("Activar JIT") { coordinator.enable() }.disabled(coordinator.busy || pairing.active)
                Button("Restablecer DDI") { coordinator.resetDDI() }.disabled(coordinator.busy || pairing.active)
                if coordinator.busy { ProgressView() }
                Text(coordinator.status).font(.footnote)
            }
        }
        .navigationTitle("JIT integrado")
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } } }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.data]) { result in
            do {
                try MeloNXPairingStore.importFile(result.get())
                imported = true
                coordinator.report("Archivo importado. Comprobá la conexión con LocalDevVPN.")
            } catch { coordinator.report(error.localizedDescription) }
        }
    }
}
